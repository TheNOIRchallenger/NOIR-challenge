# NOIR Resource Vault

A minimal, original, read-only resource website for links, images and reports.

## Publish it

GitHub Pages can publish an `index.html` as a live website. Create a repository, upload `index.html`, then enable **Settings → Pages → Deploy from a branch**. GitHub will provide the live `github.io` address. Changes can take a few minutes to appear.

## Owner-only content

This public build intentionally has no visitor add/remove controls. The resource list is stored in `RESOURCE_DATA` inside `index.html`. Only someone with write/admin access to the repository can change the published content.

For stronger private administration (accounts, passwords, database storage, upload permissions and audit logs), use a server-side backend rather than putting an admin password in JavaScript.

## Copyright

The site code, layout and UI copy in this package were created for this project and do not intentionally reproduce a third-party site's code or artwork.

Important: this does **not** make third-party material you upload copyright-free. Logos, reports, photographs, screenshots, articles and other external material can still belong to their respective owners. Only publish material you created, licensed, or otherwise have permission to publish.

The name “NOIR” is used here as a project name; this is not a trademark-clearance opinion.

## Files

- `index.html` — complete deployable website
